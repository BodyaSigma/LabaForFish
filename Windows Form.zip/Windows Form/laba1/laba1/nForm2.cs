﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace laba1
{
    public partial class nForm2 : laba1.Form1
    {
        public nForm2()
        {
            InitializeComponent();
        }
    }
}
